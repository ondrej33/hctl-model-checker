# This file was generated from setup.py
version = '0.5.6'
